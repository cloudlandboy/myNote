function listCategory() { 
    return "商品分类列表";
} 
   
function listProduct() { 
    return "商品列表";
} 
 
exports.listCategory = listCategory; 
exports.listProduct = listProduct